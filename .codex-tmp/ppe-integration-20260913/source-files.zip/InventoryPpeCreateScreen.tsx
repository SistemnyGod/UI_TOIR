import { useEffect, useState } from "react";
import type { ScreenId } from "../../types";
import { useInventoryRepository } from "../../repositories/inventoryRepositoryContext";
import { PpeIssueDocumentConstructor } from "./PpeIssueDocumentConstructor";
import { PpeIssueWorkflowScreen } from "./ppe/PpeIssueWorkflowScreen";

export function InventoryPpeCreateScreen({ onNavigate, onNotify, currentUserId }: { onNavigate: (screen: ScreenId) => void; onNotify: (message: string) => void; currentUserId?: string }) {
  const repository = useInventoryRepository();
  const [enabled, setEnabled] = useState<boolean | null>(null);
  useEffect(() => { void repository.getPpeIssueDocumentCapabilities().then((value) => setEnabled(value.enabled)).catch(() => setEnabled(false)); }, [repository]);
  if (enabled === null) return <div className="ppe-document-state">Проверяем доступность конструктора…</div>;
  return enabled ? <PpeIssueDocumentConstructor currentUserId={currentUserId} onNavigate={onNavigate} onNotify={onNotify} /> : <PpeIssueWorkflowScreen currentUserId={currentUserId} onNavigate={onNavigate} onNotify={onNotify} />;
}
