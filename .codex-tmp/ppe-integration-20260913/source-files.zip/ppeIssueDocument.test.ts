import { describe, expect, it } from "vitest";
import { isPpeIssueDocumentConfirmable, mergeServerLines, problemMessagesOf, toLineInput, validateDraftLines } from "../features/inventory/PpeIssueDocumentConstructor";
import { ApiError } from "../api/client";

describe("PPE issue document confirmation", () => {
  it("does not overwrite edits or resurrect removed lines after a delayed save", () => {
    const line = { id: "line", normRowId: "norm", itemId: "item", issueDate: "2026-09-08", quantity: 1, unitPriceMinor: 100, itemName: "Каска", normName: "Защита головы", unitSymbol: "шт.", approved: true };
    const document = { content: { lines: [line], normRows: [] } } as never;
    expect(mergeServerLines(document, [{ ...line, quantity: 3 }], [toLineInput(line)])[0].quantity).toBe(3);
    expect(mergeServerLines(document, [], [toLineInput(line)])).toEqual([]);
    const added = { ...line, id: "new" };
    expect(mergeServerLines(document, [line, added], [toLineInput(line)]).map((entry) => entry.id)).toEqual(["line", "new"]);
  });

  it("allows only a non-confirmed document with no server validation errors", () => {
    const clean = { status: "draft", validation: { errors: [] } };
    expect(isPpeIssueDocumentConfirmable(clean as never)).toBe(true);
    expect(isPpeIssueDocumentConfirmable({ ...clean, validation: { errors: [{ code: "price", lineId: "line", message: "Цена обязательна" }] } } as never)).toBe(false);
    expect(isPpeIssueDocumentConfirmable({ ...clean, status: "confirmed" } as never)).toBe(false);
  });

  it("renders ValidationProblemDetails fields and blocks manual control without a reason", () => {
    const error = new ApiError("Validation failed", 400, { problem: { errors: { normChanged: ["Подтвердите изменение нормы"], lines: ["Цена должна быть положительной"] } } });
    expect(problemMessagesOf(error)).toEqual(["Подтвердите изменение нормы", "lines: Цена должна быть положительной"]);
    expect(validateDraftLines([{ itemName: "Каска", manualControlConfirmed: true, exceptionReason: "" }] as never)).toContain("Каска");
    expect(validateDraftLines([{ itemName: "Каска", manualControlConfirmed: true, exceptionReason: "Переходный период" }] as never)).toBe("");
  });

  it("does not include server display fields in the persisted line fingerprint", () => {
    const input = toLineInput({ id: "line", normRowId: "norm", itemId: "item", issueDate: "2026-09-08", quantity: 1, unitPriceMinor: 100, itemName: "Каска", normName: "Защита головы", unitSymbol: "ед. не подтверждена", approved: true });
    expect(input).toEqual({ id: "line", normRowId: "norm", itemId: "item", issueDate: "2026-09-08", quantity: 1, unitPriceMinor: 100, sizeText: "", exceptionReason: "", manualControlConfirmed: false });
  });
});
